
library(testthat)
library(SingleCellComplexHeatMap)

test_check("SingleCellComplexHeatMap")